#ifndef PAGE_REPLACEMENT_H
#define PAGE_REPLACEMENT_H

#include "page_table.h"
#include "disk.h"
#include <iostream>
#include <string>

using namespace std;

class Page_Replacement
{
public:
    /*
     * This is the method called when a page fault occurs. Your work begins here!
     */
    static void page_fault_handler(Page_Table *pt, int page);
    
    /*
     * Set the page replacement algorithm to use
     */
    static void set_algorithm(const std::string& algorithm);
    
    /*
     * Print execution statistics
     */
    static void print_statistics();
    
    /*
     * Reset statistics counters
     */
    static void reset_statistics();
    
    /*
     * Cleanup resources
     */
    static void cleanup();

    // ADICIONADO
    //static void initialize_data_structures(Page_Table *pt, const std::string& algorithm);
};

#endif